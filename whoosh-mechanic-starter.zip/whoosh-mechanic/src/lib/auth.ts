import { cookies } from 'next/headers';
import { SignJWT, jwtVerify } from 'jose';
import { db } from './db';
const COOKIE = 'wm_session';
function secret() {
  const value = process.env.SESSION_SECRET;
  if (!value || value.length < 32) throw new Error('SESSION_SECRET должен содержать минимум 32 символа');
  return new TextEncoder().encode(value);
}
export async function createSession(userId: string) {
  const token = await new SignJWT({ sub: userId }).setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt().setExpirationTime('7d').sign(secret());
  (await cookies()).set(COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 60*60*24*7 });
}
export async function currentUser() {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret());
    if (!payload.sub) return null;
    return await db.user.findUnique({ where: { id: String(payload.sub) }, select: { id:true, name:true, role:true, active:true } });
  } catch { return null; }
}
export async function requireUser() {
  const user = await currentUser();
  if (!user || !user.active) throw new Error('UNAUTHORIZED');
  return user;
}
export async function requireRole(...roles: Array<'OWNER'|'ADMIN'|'EMPLOYEE'>) {
  const user = await requireUser();
  if (!roles.includes(user.role)) throw new Error('FORBIDDEN');
  return user;
}
export async function destroySession() {
  (await cookies()).set(COOKIE, '', { httpOnly:true, path:'/', maxAge:0 });
}
