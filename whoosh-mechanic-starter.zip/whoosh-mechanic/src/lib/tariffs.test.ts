import {test} from 'node:test';
import assert from 'node:assert/strict';
import {calculateShift,DEFAULT_TARIFFS} from './tariffs';
test('rounds team average down',()=>{assert.deepEqual(calculateShift(51,2,DEFAULT_TARIFFS),{averageOutput:25,payout:7690})});
test('personal output is not part of salary formula',()=>{assert.equal(calculateShift(50,2,DEFAULT_TARIFFS).payout,7690)});
test('reports missing tariff below and above range',()=>{assert.equal(calculateShift(13,1,DEFAULT_TARIFFS).payout,null);assert.equal(calculateShift(36,1,DEFAULT_TARIFFS).payout,null)});
