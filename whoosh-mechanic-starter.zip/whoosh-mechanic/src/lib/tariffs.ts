export const DEFAULT_TARIFFS: Record<number, number> = {
  14:4788, 15:5814, 16:5814, 17:6840, 18:6840, 19:6840, 20:6840,
  21:7010, 22:7180, 23:7350, 24:7520, 25:7690, 26:7860, 27:8030,
  28:8200, 29:8370, 30:8540, 31:8710, 32:8880, 33:9050, 34:9220, 35:9390
};
export function calculateShift(teamOutput: number, teamSize: number, tariffs: Record<number, number>) {
  if (!Number.isInteger(teamOutput) || teamOutput < 0) throw new Error('Выработка должна быть целым неотрицательным числом');
  if (!Number.isInteger(teamSize) || teamSize < 1 || teamSize > 100) throw new Error('Проверьте количество сотрудников');
  const average = Math.floor(teamOutput / teamSize);
  return { averageOutput: average, payout: tariffs[average] ?? null };
}
