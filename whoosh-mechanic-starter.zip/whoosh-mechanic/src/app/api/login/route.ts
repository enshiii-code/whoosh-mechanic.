import {NextResponse} from 'next/server';
import {z} from 'zod';
import bcrypt from 'bcryptjs';
import {db} from '@/lib/db';
import {createSession} from '@/lib/auth';
export async function POST(req:Request){try{const body=z.object({email:z.string().email(),password:z.string().min(1)}).parse(await req.json());const user=await db.user.findUnique({where:{email:body.email.toLowerCase()}});if(!user||!user.active||!(await bcrypt.compare(body.password,user.passwordHash)))return NextResponse.json({error:'Неверные данные или доступ заблокирован'},{status:401});await createSession(user.id);return NextResponse.json({ok:true});}catch{return NextResponse.json({error:'Проверьте введённые данные'},{status:400});}}
