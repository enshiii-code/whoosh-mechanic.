import {NextResponse} from 'next/server';
import {currentUser} from '@/lib/auth';
import {db} from '@/lib/db';
export async function GET(){const user=await currentUser();if(!user||!user.active)return NextResponse.json({error:'Не авторизован'},{status:401});const shifts=await db.shift.findMany({where:{userId:user.id},orderBy:{date:'desc'},take:100,select:{id:true,date:true,teamOutput:true,teamSize:true,personalOutput:true,averageOutput:true,payout:true}});return NextResponse.json({user,shifts});}
