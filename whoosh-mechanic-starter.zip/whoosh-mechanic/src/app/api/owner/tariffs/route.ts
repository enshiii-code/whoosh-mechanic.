import {NextResponse} from 'next/server';
import {z} from 'zod';
import {requireRole} from '@/lib/auth';
import {db} from '@/lib/db';
export async function GET(){try{await requireRole('OWNER');const tariffs=await db.tariff.findMany({orderBy:{output:'asc'}});return NextResponse.json({tariffs});}catch{return NextResponse.json({error:'Только владелец может просматривать настройки тарифов'},{status:403});}}
export async function PUT(req:Request){try{const actor=await requireRole('OWNER');const body=z.object({tariffs:z.array(z.object({output:z.number().int().min(0).max(1000),payout:z.number().int().min(0).max(10000000)})).min(1)}).parse(await req.json());await db.$transaction(async tx=>{await tx.tariff.deleteMany();await tx.tariff.createMany({data:body.tariffs});await tx.auditLog.create({data:{actorId:actor.id,action:'TARIFFS_REPLACED'}})});return NextResponse.json({ok:true});}catch{return NextResponse.json({error:'Недостаточно прав или некорректная таблица'},{status:403});}}
