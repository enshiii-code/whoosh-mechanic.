'use client';
import { useEffect, useMemo, useState } from 'react';
type Shift = { id:string; date:string; teamOutput:number; teamSize:number; personalOutput:number|null; averageOutput:number; payout:number|null };
const money = (n:number) => new Intl.NumberFormat('ru-RU').format(n) + ' ₽';
export default function Home() {
  const [user,setUser] = useState<{name:string;role:string}|null>(null);
  const [shifts,setShifts] = useState<Shift[]>([]);
  const [busy,setBusy] = useState(true);
  const [error,setError] = useState('');
  const [form,setForm] = useState({date:new Date().toISOString().slice(0,10),teamOutput:'',teamSize:'2',personalOutput:''});
  const [preview,setPreview] = useState<{averageOutput:number;payout:number|null}|null>(null);
  async function load() {
    setBusy(true);
    try {
      const r = await fetch('/api/me',{cache:'no-store'});
      if (!r.ok) { setUser(null); setBusy(false); return; }
      const d = await r.json(); setUser(d.user); setShifts(d.shifts);
    } catch { setError('Не удалось загрузить данные'); }
    setBusy(false);
  }
  useEffect(()=>{load()},[]);
  const monthTotal = useMemo(()=> {
    const now = new Date();
    return shifts.filter(s=>{const d=new Date(s.date);return d.getMonth()===now.getMonth()&&d.getFullYear()===now.getFullYear()}).reduce((a,s)=>a+(s.payout??0),0);
  },[shifts]);
  const avgPersonal = useMemo(()=> {
    const vals=shifts.filter(s=>s.personalOutput!==null).map(s=>s.personalOutput as number);
    return vals.length ? (vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(1).replace('.',',') : '—';
  },[shifts]);
  async function calculate() {
    setError('');
    const r=await fetch('/api/calculate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({teamOutput:Number(form.teamOutput),teamSize:Number(form.teamSize)})});
    const d=await r.json(); if(!r.ok){setError(d.error||'Ошибка расчёта');return;} setPreview(d);
  }
  async function addShift(e:React.FormEvent) {
    e.preventDefault(); setError('');
    const r=await fetch('/api/shifts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...form,teamOutput:Number(form.teamOutput),teamSize:Number(form.teamSize),personalOutput:form.personalOutput===''?null:Number(form.personalOutput)})});
    const d=await r.json(); if(!r.ok){setError(d.error||'Не удалось сохранить смену');return;}
    setForm({...form,teamOutput:'',personalOutput:''});setPreview(null);await load();
  }
  async function logout(){await fetch('/api/logout',{method:'POST'});setUser(null);setShifts([]);}
  if(busy) return <main className="shell"><div className="loading">WHOOSH <b>MECHANIC</b><span>ЗАГРУЗКА</span></div></main>;
  if(!user) return <main className="shell auth"><div className="brand">WHOOSH <b>MECHANIC</b><i>INTERNAL CREW TOOL</i></div><section className="authbox"><p className="eyebrow">ЛИЧНЫЙ КАБИНЕТ</p><h1>Войти в систему</h1><p className="muted">Войдите по личным данным или активируйте приглашение.</p><a className="primary wide" href="/login">Продолжить <span>↗</span></a><a className="textlink" href="/activate">У меня есть код приглашения</a></section><footer>НЕОФИЦИАЛЬНЫЙ ВНУТРЕННИЙ СЕРВИС</footer></main>;
  return <main className="shell">
    <header className="topbar"><div className="brand">WHOOSH <b>MECHANIC</b><i>CREW / PERSONAL</i></div><div className="userbox"><span>{user.name}</span><small>{user.role==='OWNER'?'ВЛАДЕЛЕЦ':user.role==='ADMIN'?'АДМИНИСТРАТОР':'МЕХАНИК'}</small><button className="quiet" onClick={logout}>Выйти ↗</button></div></header>
    <section className="hero"><div><p className="eyebrow">ЛИЧНАЯ ВЫРАБОТКА / {new Date().toLocaleDateString('ru-RU',{month:'long',year:'numeric'}).toUpperCase()}</p><h1>Твоя работа.<br/><em>Твой результат.</em></h1><p className="muted">Начисления по сменам — без лишних действий.</p></div><div className="hero-mark">WM<span>///</span></div></section>
    <section className="summary"><div className="summary-main"><span>ЗАРАБОТОК ЗА МЕСЯЦ</span><strong>{money(monthTotal)}</strong><small>По сохранённым начислениям</small></div><div className="summary-side"><div><span>СМЕН</span><strong>{shifts.length}</strong></div><div><span>СРЕДНЯЯ ЛИЧНАЯ ВЫРАБОТКА</span><strong>{avgPersonal}</strong></div></div></section>
    <div className="sectionhead"><div><p className="eyebrow">НОВАЯ ЗАПИСЬ</p><h2>Добавить смену</h2></div><span className="index">01 / SHIFT</span></div>
    <section className="entry">
      <form onSubmit={addShift} className="formgrid">
        <label>ДАТА СМЕНЫ<input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} required/></label>
        <label>ВЫРАБОТКА БРИГАДЫ<input type="number" min="0" step="1" placeholder="Например, 51" value={form.teamOutput} onChange={e=>{setForm({...form,teamOutput:e.target.value});setPreview(null)}} required/></label>
        <label>СОТРУДНИКОВ НА СМЕНЕ<input type="number" min="1" max="100" step="1" value={form.teamSize} onChange={e=>{setForm({...form,teamSize:e.target.value});setPreview(null)}} required/></label>
        <label>ЛИЧНАЯ ВЫРАБОТКА <small>НЕ ВЛИЯЕТ НА ЗАРПЛАТУ</small><input type="number" min="0" step="1" placeholder="Необязательно" value={form.personalOutput} onChange={e=>setForm({...form,personalOutput:e.target.value})}/></label>
        <div className="calcrow"><button type="button" className="secondary" onClick={calculate} disabled={!form.teamOutput}>Рассчитать выплату <span>↗</span></button>{preview&&<div className="preview"><small>СРЕДНЕЕ: {preview.averageOutput} / СМЕНА</small><b>{preview.payout===null?'Нет тарифа':money(preview.payout)}</b></div>}</div>
        <button className="primary submit" type="submit">Сохранить смену <span>＋</span></button>
      </form>
      {error&&<p className="error">{error}</p>}
      <p className="formula">РАСЧЁТ: floor(выработка бригады ÷ количество сотрудников). Личная выработка хранится отдельно.</p>
    </section>
    <div className="sectionhead historyhead"><div><p className="eyebrow">ЖУРНАЛ НАЧИСЛЕНИЙ</p><h2>Последние смены</h2></div><span className="index">{String(shifts.length).padStart(2,'0')} / TOTAL</span></div>
    <section className="history">{shifts.length===0?<p className="empty">Записей пока нет. Добавь первую смену выше.</p>:shifts.slice(0,12).map(s=><div className="shift" key={s.id}><time>{new Date(s.date).toLocaleDateString('ru-RU',{day:'2-digit',month:'short',year:'numeric'})}</time><span>{s.teamOutput} сам. / {s.teamSize} чел.<small>СРЕДНЕЕ {s.averageOutput} · ЛИЧНОЕ {s.personalOutput??'—'}</small></span><b>{s.payout===null?'Нет тарифа':money(s.payout)}</b></div>)}</section>
    <footer>WHOOSH MECHANIC · НЕОФИЦИАЛЬНЫЙ ВНУТРЕННИЙ СЕРВИС</footer>
  </main>;
}
