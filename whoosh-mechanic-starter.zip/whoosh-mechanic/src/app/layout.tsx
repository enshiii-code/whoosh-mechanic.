import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'WHOOSH MECHANIC', description: 'Личный учёт смен и начислений механика' };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="ru"><body>{children}</body></html>;
}
